## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, eval=FALSE)

## ------------------------------------------------------------------------
#  devtools::install_github("lmxblur/Adv_lab6", subdir="lab6")

